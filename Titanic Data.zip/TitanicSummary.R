library(readr)
boat <- read.csv(file="titanic.csv", header=TRUE, sep=",")
View(boat)
head(boat)
sapply(boat,class)
boat$Survived<-as.character(boat$Survived)
boat$Pclass<-as.character(boat$Pclass)
summary(boat)
summary(boat$Age)
summary(boat$Fare)
max(boat$Fare)
min(boat$Fare)
mean(boat$Fare)
sd(boat$Fare)
aggregate(Age~Survived,boat,mean)
aggregate(Age~Sex,boat,mean)
aggregate(Fare~Sex,boat,mean)

# Scatter
jpeg("TitanicFare&Survivor.jpg")
plot(Age[which(boat$Survived==0)]~Fare[which(boat$Survived==0)],data=boat,
     xlab="Ticket Fare", ylab="Age",main="Titanic Fare",
     cex.lab=.75,cex.axis=.5)
par(new=T)
plot(Age[which(boat$Survived==1)]~Fare[which(boat$Survived==1)],data=boat,
     col="red",xlab="", ylab="",main="",axes=F,
     cex.lab=.75,cex.axis=.5)
legend("topright",legend=c("Survived","Not Survived"),pch=c(1,1),col=c("black", "red"),cex=.75)
dev.off()

# Scatter
jpeg("TitanicFare&Gender.jpg")
plot(Age[which(boat$Sex=='female')]~Fare[which(boat$Sex=='female')],data=boat,
     xlab="Ticket Fare", ylab="Age",main="Titanic Fare",
     cex.lab=.75,cex.axis=.5)
par(new=T)
plot(Age[which(boat$Sex=='male')]~Fare[which(boat$Sex=='male')],data=boat,
     col="red",xlab="", ylab="",main="",axes=F,
     cex.lab=.75,cex.axis=.5)
dev.off()

# Box
jpeg("TitanicSurvivorAge.jpg")
boxplot(boat$Age~boat$Survived,xlab="Survived",ylab="Age",main="Titanic Survivor (Age)",cex.axis=0.75)
dev.off()

jpeg("TitanicSurvivorFare.jpg")
boxplot(boat$Fare~boat$Survived,xlab="Survived",ylab="Fare",main="Titanic Survivor (Fare)",cex.axis=0.75)
dev.off()


# Histogram
jpeg("TitanicFare.jpg")
dT<-density(boat$Fare) # Kernel Density
plot(dT)
dev.off()
