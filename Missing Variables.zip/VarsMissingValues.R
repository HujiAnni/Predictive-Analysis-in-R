library(readr)
boat <- read_csv("titanic.csv")
#function to find number of observations where age is a missing value
summary(boat)

sum(is.na(boat$Age))
boat$AgeAVG<-boat$Age
boat<-within(boat,AgeAVG[is.na(Age)]<-mean(boat$Age,na.rm=TRUE))
View(boat)

sum(is.na(boat$Embarked))
table(boat$Embarked)
boat<-within(boat,Embarked[is.na(Embarked)]<-"S")

sum(is.na(boat$Cabin))
table(boat$Cabin)
boat<-within(boat,Cabin[is.na(Cabin)]<-"G6")
