library(readxl)
Revenue <- read_excel("Revenue.xlsx", col_types = c("numeric","text","numeric","numeric"))
summary(Revenue)
mean(Revenue$Income)
mean(Revenue$Income,na.rm=TRUE)
View(Revenue)
RevenueLm<-lm(Revenue$Revenue~Revenue$Electronic+Revenue$Years+Revenue$Income)
summary(RevenueLm)
Revenue$IncNA<-0
Revenue<-within(Revenue,IncNA[is.na(Income)]<-1)
View(Revenue)
aggregate(Revenue~IncNA,Revenue,mean)

#ReplacingMissingValues
View(Revenue)
aggregate(Revenue~IncNA,Revenue,mean)
Revenue$IncNAavg<-Revenue$Income
Revenue<-within(Revenue,IncNAavg[is.na(Income)]<-mean(Income,na.rm=TRUE))
View(Revenue)
RevenueLm<-lm(Revenue$Revenue~Revenue$IncNA+Revenue$Electronic+Revenue$Years+Revenue$IncNAavg)
summary(RevenueLm)
