# describing our sample
head(WMfg)
tail(WMfg,10)
summary(WMfg)
summary(WMfg$Time)
mean(WMfg$Time)
sd(WMfg$Time)
aggregate(Time~Expedite,WMfg,mean)
aggregate(Time~Expedite,WMfg,sd)
cor(WMfg$Time,WMfg$Pieces)
# cor(WMfg,WMfg) can't use this qs Expedite is Character
cor(WMfg[c(1,2,4)],WMfg[c(1,2,4)]) # correlation for 3 quantitative variables
