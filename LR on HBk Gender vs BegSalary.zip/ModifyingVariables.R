#library(readxl)
#WMfg <- read_excel("WMfg.xlsx")
MRModel<-lm(WMfg$Time~WMfg$Pieces+WMfg$Operations+WMfg$Expedite)
summary(MRModel)
WMfgM<-WMfg
WMfgM$PiecesXOperation<-WMfg$Pieces*WMfg$Operations
head(WMfgM)
127*7
WMfgM<-WMfgM[,c(1,2,3,5,4)]
head(WMfgM)
cor(WMfgM[c(1,2,4,5)],WMfgM[c(1,2,4,5)])
MRModel<-lm(WMfgM$Time~WMfgM$Pieces+WMfgM$Operations+WMfgM$Expedite+WMfgM$PiecesXOperation)
summary(MRModel)            

