library(readxl)
HBk <- read_excel("HBK.xlsx")
HBkLM<-lm(HBk$BegSalary~HBk$Education)
summary(HBkLM)
HBkLM1<-lm(HBk$BegSalary~HBk$Education+HBk$GENDER+HBk$Experience)
summary(HBkLM1)
HBkM<-HBk
HBkM$LNSal<- log(HBkM$BegSalary)
head(HBkM)
log(4620)
HBkLM2<-lm(HBkM$LNSal~HBkM$Education+HBkM$GENDER+HBkM$Experience)
summary(HBkLM2)
HBkLM2$coefficients
exp(HBkLM2$coefficients["HBkM$GENDER"])
