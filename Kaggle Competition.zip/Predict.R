library(readr)
boat<- read_csv("train.csv")
boat$Survived<-as.factor(boat$Survived)
boatLR<-glm(Survived~Sex,family=binomial(),data=boat)

boattest<- read_csv("test.csv")
boattest$survive.prod<-predict(boatLR,boattest,type="response")
boattest$survive<-round(boattest$survive.prod)
View(boattest)

submission <- c()
submission$PassengerID <-boattest$PassengerId
submission$Survived <-boattest$survive
write.csv(submission, file = "submission.csv")

