library(readr)
boat<- read_csv("train.csv")
boat$Survived<-as.factor(boat$Survived)
boat$AgeNAavg<-boat$Age
boat<-within(boat,AgeNAavg[is.na(Age)]<-mean(Age,na.rm=TRUE))
sum(is.na(boat$Embarked))
table(boat$Embarked)
boat<-within(boat,Embarked[is.na(Embarked)]<-"S")
View(boat)

# Sex_Age_Fare
boatLR<-glm(Survived~Sex+Age+Fare,family=binomial(),data=boat)
summary(boatLR)
boatHat<-predict(boatLR, boat, type="response")
TRT<-table(boat$Survived,boatHat>.5)
TRT
TRA<-(TRT[1,1]+TRT[2,2])/nrow(boat)
TRA

# Sex_Age
boatLR1<-glm(Survived~Sex+AgeNAavg,family=binomial(),data=boat)
summary(boatLR1)
boatHat1<-predict(boatLR1, boat, type="response")
TRT1<-table(boat$Survived,boatHat1>.5)
TRT1
TRA1<-(TRT1[1,1]+TRT1[2,2])/nrow(boat)
TRA1

# Age_Fare
boatLR2<-glm(Survived~AgeNAavg+Fare,family=binomial(),data=boat)
summary(boatLR2)
boatHat2<-predict(boatLR2, boat, type="response")
TRT2<-table(boat$Survived,boatHat2>.5)
TRT2
TRA2<-(TRT2[1,1]+TRT2[2,2])/nrow(boat)
TRA2

# Age_Sex_SibSp_Pclass
boatLR3<-glm(Survived~AgeNAavg+Sex+SibSp+Pclass,family=binomial(),data=boat)
summary(boatLR3)
boatHat3<-predict(boatLR3, boat, type="response")
TRT3<-table(boat$Survived,boatHat3>.5)
TRT3
TRA3<-(TRT3[1,1]+TRT3[2,2])/nrow(boat)
TRA3

# Age_Sex_Pclass
boatLR4<-glm(Survived~AgeNAavg+Sex+Pclass,family=binomial(),data=boat)
summary(boatLR4)
boatHat4<-predict(boatLR4, boat, type="response")
TRT4<-table(boat$Survived,boatHat4>.5)
TRT4
TRA4<-(TRT4[1,1]+TRT4[2,2])/nrow(boat)
TRA4

boatLRbest<-glm(Survived~Age+Sex+Pclass,family=binomial(),data=boat)

boattest<- read_csv("test.csv")
boattest$AgeNAavg<-boattest$Age
boattest<-within(boattest,AgeNAavg[is.na(Age)]<-mean(Age,na.rm=TRUE))
boattest$survive.prod<-predict(boatLR4,boattest,type="response")
boattest$survive<-round(boattest$survive.prod)
View(boattest)

submission <- c()
submission$PassengerID <-boattest$PassengerId
submission$Survived <-boattest$survive
write.csv(submission, file = "submission.csv")

