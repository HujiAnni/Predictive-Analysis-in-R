summary(WMfg$Time)
boxplot(WMfg$Time)
boxplot(WMfg$Time~WMfg$Expedite)
boxplot(WMfg$Time~WMfg$Expedite,xlab="Expedite",ylab="Time (hrs)",cex.axis=0.75)
