#install.packages("readr")
library(readr)
HBk <- read.csv(file="HarrisBank.csv", header=TRUE, sep=",")
summary(HBk)
head(HBk)
# Scatter Plot of BegSalary as a function of Education
plot(HBk$Education,HBk$BegSalary)
plot(BegSalary~Education,data=HBk,xlab="yrs of Eduation", ylab="Salary",main="Harris Bank",cex.lab=.75,cex.axis=.5)

jpeg("HarrisonBankBegSalaryvsEducation.jpg")
plot(BegSalary[which(HBk$GENDER==0)]~Education[which(HBk$GENDER==0)],data=HBk,
     xlab="yrs of Eduation", ylab="Salary",main="Harris Bank",
     cex.lab=.75,cex.axis=.5)
par(new=T)
plot(BegSalary[which(HBk$GENDER==1)]~Education[which(HBk$GENDER==1)],data=HBk,
     col="red",xlab="", ylab="",main="",axes=F,
     cex.lab=.75,cex.axis=.5)
dev.off()

# boxplot of BegSalary as a function of GENDER
boxplot(HBk$BegSalary)
boxplot(HBk$BegSalary~HBk$GENDER)
jpeg("HarrisonBankBegSalaryvsGENDER.jpg")
boxplot(HBk$BegSalary~HBk$GENDER,xlab="Gender",ylab="Salary",main="Harris Bank",cex.axis=0.75)
dev.off()
