cor(WMfg$Time,WMfg$Pieces)
aggregate(Time~Expedite,WMfg,mean)

plot(WMfg$Pieces,WMfg$Time)
plot(Time~Pieces,data=WMfg)
plot(Time~Pieces,data=WMfg,xlab="# Pieces", ylab="Completion time (mins)",main="WMfg")
plot(Time~Pieces,data=WMfg,xlab="# Pieces", ylab="Completion time (mins)",main="WMfg",cex.lab=.75,cex.axis=.5)
plot(Time[which(WMfg$Expedite==0)]~Pieces[which(WMfg$Expedite==0)],data=WMfg,
     xlab="# Pieces", ylab="Completion time (mins)",main="WMfg",
     cex.lab=.75,cex.axis=.5)
par(new=T)
plot(Time[which(WMfg$Expedite==1)]~Pieces[which(WMfg$Expedite==1)],data=WMfg,
     col="red",xlab="# Pieces", ylab="Completion time (mins)",main="WMfg",
     cex.lab=.75,cex.axis=.5)

plot(Time[which(WMfg$Expedite==1)]~Pieces[which(WMfg$Expedite==1)],data=WMfg,
     col="red",xlab="# Pieces", ylab="Completion time (mins)",main="WMfg",
     cex.lab=.75,cex.axis=.5,xlim=c(0,1000),ylim=c(0,1000))
par(new=T)
plot(Time[which(WMfg$Expedite==0)]~Pieces[which(WMfg$Expedite==0)],data=WMfg,
     xlab='', ylab='', axes=F,
     cex.lab=.75,cex.axis=.5,xlim=c(0,1000),ylim=c(0,1000))

