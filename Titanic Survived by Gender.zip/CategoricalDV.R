library(readxl)
ERDr<- read_excel("EasyReadersData.xlsx", col_types = c("text", "text", "numeric", "numeric", "numeric"))
summary(ERDr)
GP<-table(ERDr$Buy,ERDr$Gender)
GP #rows are Purchase, cols Gender
prop.table(GP) # % of total
prop.table(GP,1) # 1 is want row %
prop.table(GP,2) # 2 is want col %
boxplot(ERDr$Purchases~ERDr$Buy,outline=FALSE)
boxplot(ERDr$YoungReaders~ERDr$Buy,outline=FALSE)
boxplot(ERDr$Spend~ERDr$Buy,outline=FALSE)
ERDrLM<-lm(ERDr$Buy~ERDr$Purchases+ERDr$Gender+ERDr$YoungReaders)
summary(ERDrLM)