#load data
library(readr)
boat <- read_csv("titanic.csv")
head(boat)
#look at summary stats
summary(boat)
mean(boat$Survived)

#survival by gender
SurvByGender<-table(boat$Survived,boat$Sex)
SurvByGender # rows are survived, cols are gender
prop.table(SurvByGender,2)

#logistic regression (survival as a function of gender)
boat$Survived<-as.factor(boat$Survived)
boatLR<-glm(Survived~Sex,family=binomial(),data=boat)
summary(boatLR)
boat.prob<- predict(boatLR,boat, type="response")
table(boat$Survived,boat.prob>.5)

#evaluate model
CT<-table(boat$Survived,boat.prob>.5)
Accuracy<-(CT[2,2]+CT[1,1])/nrow(boat)
Accuracy

