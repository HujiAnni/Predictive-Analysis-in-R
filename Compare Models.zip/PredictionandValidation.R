library(caTools)
set.seed(999) 
sample<-sample.split(ERDr$Buy, SplitRatio = .85)
train<-subset(ERDr, sample == TRUE)
test<-subset(ERDr, sample == FALSE)
ERDrGLM<-glm(Buy~Gender+YoungReaders,family=binomial(),data=train)
BuyHat<-predict(ERDrGLM, test, type="response")
HOT<-table(test$Buy,BuyHat>.5)
HO<-(HOT[1,1]+HOT[2,2])/nrow(test)
HO
BuyHat<-predict(ERDrGLM, train, type="response")
BuyHat
TRT<-table(train$Buy,BuyHat>.5)
TR<-(TRT[1,1]+TRT[2,2])/nrow(train)
TR