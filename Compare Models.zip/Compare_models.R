library(caTools)
set.seed(999) 
library(readr)
boat <- read_csv("titanic.csv")
boat$Survived<-as.factor(boat$Survived)
sample<-sample.split(boat$Survived, SplitRatio = .85)
train<-subset(boat, sample == TRUE)
test<-subset(boat, sample == FALSE)
boatLR<-glm(Survived~Sex,family=binomial(),data=train)
boatHat<-predict(boatLR, train, type="response")
TRT<-table(train$Survived,boatHat>.5)
TRT
TRA<-(TRT[1,1]+TRT[2,2])/nrow(train)
TRA
testHat<-predict(boatLR, test, type="response")
HOT<-table(test$Survived,testHat>.5)
HOT
HOA<-(HOT[1,1]+HOT[2,2])/nrow(test)
HOA
